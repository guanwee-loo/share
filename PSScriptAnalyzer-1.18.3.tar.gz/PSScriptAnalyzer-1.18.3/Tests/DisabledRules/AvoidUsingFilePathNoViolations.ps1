﻿Get-ChildItem "../Test"
Import-Module "Random"