﻿# give it 3 positional parameters
Get-Command "abc" 4 4.3