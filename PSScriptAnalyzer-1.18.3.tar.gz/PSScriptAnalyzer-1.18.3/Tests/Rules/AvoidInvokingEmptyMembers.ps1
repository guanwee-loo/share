﻿#The belowed expression works fine but such format will cause potential bugs
"abc".('len'+'gth')

#This expression is fine as there is no operation in parenthesis
"abc".('len')