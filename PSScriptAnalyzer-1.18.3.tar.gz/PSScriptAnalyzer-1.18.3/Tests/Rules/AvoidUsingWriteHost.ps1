﻿Clear-Host
cls
Write-Host "aaa"
clear
[System.Console]::Write("abcdefg");
[System.Console]::WriteLine("No console.writeline plz!");

function Test
{
    Write-Host "aaaa"
}