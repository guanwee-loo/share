﻿@{
    Severity='Warning'
    IncludeRules=@('PSAvoidUsingCmdletAliases',
                    'PSAvoidUsingPositionalParameters',
                    'PSAvoidUsingInternalURLs')
    ExcludeRules=@('PSAvoidUsingCmdletAliases')
}