﻿try {
    Import-Module ScriptAnalyzer
}
catch {}