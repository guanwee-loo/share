# UseUTF8EncodingForHelpFile

**Severity Level: Warning**

## Description

Check if help file uses utf8 encoding