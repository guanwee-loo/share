RESOURCE_PATH_FROM_VARS = 'resource.robot'
