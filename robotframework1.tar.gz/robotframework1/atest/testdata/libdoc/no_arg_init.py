class no_arg_init:
    """No inits here!"""

    def __init__(self):
        """This doc not shown because there are no arguments."""

    def keyword(self, arg1, arg2):
        """The only lonely keyword."""
