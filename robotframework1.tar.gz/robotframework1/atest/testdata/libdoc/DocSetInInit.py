class DocSetInInit(object):

    def __init__(self):
        self.__doc__ = 'Doc set in __init__!!'
