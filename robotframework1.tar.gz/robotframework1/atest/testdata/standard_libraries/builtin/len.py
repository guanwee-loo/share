# This module shouldn't be used as an automatic module with Evaluate,
# but should be usable as an explicit module.

value = 42
