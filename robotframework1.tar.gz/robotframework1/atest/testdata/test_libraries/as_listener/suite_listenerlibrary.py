from listenerlibrary import listenerlibrary


class suite_listenerlibrary(listenerlibrary):
    ROBOT_LIBRARY_SCOPE = "TEST SUITE"
