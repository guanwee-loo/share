from global_vars_listenerlibrary import global_vars_listenerlibrary


class global_vars_listenerlibrary_ts_scope(global_vars_listenerlibrary):
    ROBOT_LIBRARY_SCOPE = 'TEST SUITE'
