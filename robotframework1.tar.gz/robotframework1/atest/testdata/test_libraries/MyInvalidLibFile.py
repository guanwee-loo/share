raise ImportError("I'm not really a library!")
                  