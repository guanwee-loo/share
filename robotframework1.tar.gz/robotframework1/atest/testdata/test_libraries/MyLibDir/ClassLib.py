class ClassLib(object):

    def keyword_in_mylibdir_classlib(self):
        pass
