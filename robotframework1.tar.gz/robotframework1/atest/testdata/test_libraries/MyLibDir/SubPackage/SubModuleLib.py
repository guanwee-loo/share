def keyword_in_mylibdir_subpackage_submodulelib():
    pass
