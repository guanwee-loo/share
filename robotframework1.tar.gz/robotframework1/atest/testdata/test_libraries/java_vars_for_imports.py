import JavaObject as _JO
from java.util import HashMap as _HM

JAVA_OBJECT = _JO("The name of the JavaObject")
LIST__LIST_WITH_OBJECTS = [_HM({'key': 'value'}), True]

