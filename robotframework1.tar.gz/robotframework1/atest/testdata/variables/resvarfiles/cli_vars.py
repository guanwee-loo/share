SCALAR = 'Scalar from variable file from CLI'
SCALAR_WITH_ESCAPES = r'1 \ 2\\ ${inv}'
SCALAR_LIST = 'List variable value'.split()
LIST__LIST = SCALAR_LIST

PRIORITIES_1 = PRIORITIES_2 = 'Variable File from CLI'
