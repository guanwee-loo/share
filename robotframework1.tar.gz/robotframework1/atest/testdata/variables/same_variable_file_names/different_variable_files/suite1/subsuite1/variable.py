SUITE = SUITE_11 = "suite1.subsuite1"
