class local_lib(object):

    def __init__(self, argument):
        pass

    def some_kw(self):
        pass
