scalar_from_cli_varfile = 'Scalar from variable file from cli'
scalar_from_cli_varfile_with_escapes = '1 \\ 2\\\\ ${inv}'
list_var_from_cli_varfile = 'Scalar list from variable file from cli'.split()
LIST__list_var_from_cli_varfile = 'List from variable file from cli'.split()
clivar = 'This value is not taken into use because var is overridden from cli'