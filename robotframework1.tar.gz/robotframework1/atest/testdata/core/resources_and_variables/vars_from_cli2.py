def get_variables():
    return {
        'scalar_from_cli_varfile'  : ('This variable is not taken into use '
                                      'because it already exists in '
                                      'vars_from_cli.py'),
        'scalar_from_cli_varfile_2': ('Variable from second variable file '
                                      'from cli')
        }



