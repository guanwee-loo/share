

public class MultipleArguments {

    public int handler_count = 3;

 
    public void string_char_long(String s, char c, Long l) {
    }

    public void string_stringarray(String s, String[] sa) {
    }

    public void integer_boolean_char_float_double_short_short_chararray(int i, boolean b, char c, Float f, Double d, Short s1, short s2, Character[] ca) {
    }

}
