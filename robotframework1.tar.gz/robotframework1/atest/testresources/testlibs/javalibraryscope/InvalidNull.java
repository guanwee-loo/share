package javalibraryscope;

public class InvalidNull extends BaseLib{
	
	public static String ROBOT_LIBRARY_SCOPE = null; 
	
}