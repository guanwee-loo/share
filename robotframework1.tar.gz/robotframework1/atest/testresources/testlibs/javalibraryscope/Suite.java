package javalibraryscope;

public class Suite extends BaseLib{
	
	public static String ROBOT_LIBRARY_SCOPE = "TESTSUITE"; 
	
}