public class JavaVersionLibrary {

	public static final String ROBOT_LIBRARY_VERSION = "1.0";
	public static final String ROBOT_LIBRARY_DOC_FORMAT = "text";

	public Object kw() {
		return null;
	}
}
